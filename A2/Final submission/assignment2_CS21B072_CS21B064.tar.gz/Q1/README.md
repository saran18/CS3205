P1. Multithreaded MP3 Streaming Server

Objective: Create a multithreaded server to stream MP3 audio files to clients upon request

- listen for incoming connections from clients.
- send the requested MP3 file from a specified root directory (via command line arguments) to clients.
- the client upon receiving the mp3 file, plays the song using mpg123.