
max_seq_num = None
window_size = None